package com.screenassistant;

import android.app.*;
import android.os.*;
import android.content.*;
import android.media.projection.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText key, prompt;
    private TextView status, conversation;
    private final Handler handler = new Handler();
    private final Runnable refresh = new Runnable() {
        public void run() {
            status.setText(CaptureService.status);
            conversation.setText(CaptureService.transcript);
            handler.postDelayed(this, 1000);
        }
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,24);
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title = new TextView(this); title.setText("Экран · ИИ"); title.setTextSize(28); root.addView(title);
        TextView info = new TextView(this);
        info.setText("Анализ кадров экрана через OpenAI API. Это отдельный помощник, не текущий чат Codex. API оплачивается отдельно. Ключ хранится только в памяти до закрытия процесса.\nПосле запуска переключись в нужное приложение. Кадр отправляется примерно раз в 15 секунд. Стоп доступен в уведомлении."); root.addView(info);
        key = new EditText(this); key.setHint("OpenAI API-ключ"); key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); root.addView(key);
        prompt = new EditText(this); prompt.setHint("Что анализировать на экране?"); prompt.setMinLines(2); root.addView(prompt);
        Button start = new Button(this); start.setText("Начать показ экрана"); root.addView(start);
        Button send = new Button(this); send.setText("Отправить промпт"); root.addView(send);
        Button stop = new Button(this); stop.setText("Стоп"); root.addView(stop);
        status = new TextView(this); root.addView(status);
        conversation = new TextView(this); conversation.setTextIsSelectable(true); root.addView(conversation);
        start.setOnClickListener(v -> {
            if (key.getText().toString().trim().isEmpty()) { status.setText("Введи API-ключ"); return; }
            if (CaptureService.running) { status.setText("Показ уже запущен"); return; }
            CaptureService.apiKey = key.getText().toString().trim();
            CaptureService.question = prompt.getText().toString().trim();
            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(manager.createScreenCaptureIntent(), 10);
        });
        send.setOnClickListener(v -> {
            String q = prompt.getText().toString().trim();
            if (q.isEmpty()) return;
            CaptureService.question = q;
            if (!CaptureService.running) { status.setText("Сначала начни показ экрана"); return; }
            startService(new Intent(this,CaptureService.class).setAction("ASK"));
            prompt.setText("");
        });
        stop.setOnClickListener(v -> stopService(new Intent(this,CaptureService.class)));
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 11);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if (request == 10 && result == RESULT_OK && data != null) {
            startForegroundService(new Intent(this,CaptureService.class).putExtra("result",result).putExtra("permission",data));
        } else if(request == 10) { CaptureService.apiKey = ""; status.setText("Показ экрана отменён"); }
    }
    @Override protected void onResume() { super.onResume(); handler.post(refresh); }
    @Override protected void onPause() { handler.removeCallbacks(refresh); super.onPause(); }
}
